import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class SkiProblem {

	private int X;
	private int Y;
	private int[][] elevation;
	private String bestPath;
	private int startX;
	private int startY;
	private int bestPathStartX;
	private int bestPathStartY;
	private int lengthOfBestPath;
	private int dropOfBestPath;
	private int startElevation;
	private int endElevation;
	int currentElevation, previousElevation, currentDrop, currentLength;
	private ArrayList<Integer> currentPath = new ArrayList<Integer>();

	public SkiProblem() {
	}

	private void parseFile() {
		try {
			
			// CSV-Datei:
			String strFile = "C:\\Users\\Marco\\eclipse-workspace\\Kitzbuehel1\\dat\\map.txt";
			//String strFile = "C:\\Users\\Marco\\eclipse-workspace\\Kitzbuehel1\\dat\\4x4.txt";

			BufferedReader br = new BufferedReader(new FileReader(strFile));
			String strLine = "";
			StringTokenizer st = null;
			int lineNumber = 0, tokenNumber = 0;

			// Lese die Datei:
			while ((strLine = br.readLine()) != null) {

				// Nutze Separator " "
				st = new StringTokenizer(strLine, " ");
				// System.out.println(strLine);
				while (st.hasMoreTokens()) {
					tokenNumber++;
					int e = Integer.parseInt(st.nextToken());

					if (lineNumber == 0) {
						if (tokenNumber == 1) {
							X = e;
						} else if (tokenNumber == 2) {
							Y = e;
							elevation = new int[X][Y];
						}
					}
					if (lineNumber > 0) {

						elevation[tokenNumber - 1][lineNumber - 1] = e;
					}
				}

				lineNumber++;
				// Setze tokenNumber zur�ck:
				tokenNumber = 0;

			}
			br.close();
		} catch (Exception e) {
			System.out.println("Exception while reading csv file: " + e);
		}

	}

	private void showGrid() {
		// TODO Auto-generated method stub
		System.out.print("X=" + X + " Y=" + Y);
		System.out.println();

		for (int j = 0; j < Y; j++) {
			for (int i = 0; i < X; i++) {
				System.out.print(elevation[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println();
	}

	private void printGridToFile() throws FileNotFoundException {
		// TODO Auto-generated method stub
		PrintWriter writer = new PrintWriter(
				"C:\\Users\\Marco\\eclipse-workspace\\Kitzbuehel1\\dat\\map_formatted.txt");
		writer.println("X=" + X + " Y=" + Y);
		writer.println();

		for (int j = 0; j < Y; j++) {
			for (int i = 0; i < X; i++) {
				if (elevation[i][j] < 1000) {
					writer.print(" ");
				}
				if (elevation[i][j] < 100) {
					writer.print(" ");
				}
				if (elevation[i][j] < 10) {
					writer.print(" ");
				}
				writer.print(elevation[i][j] + " ");
			}
			writer.println();
		}
		writer.println();

		writer.close();
	}

	private void findBestPath() {
		// TODO Auto-generated method stub
		int count;

		lengthOfBestPath = 1;
		dropOfBestPath = 0;

		for (int j = 0; j < Y; j++) {
			for (int i = 0; i < X; i++) {
				// System.out.println();
				// System.out.println("i=" + i + ", j=" + j);

				count = 1;
				startElevation = elevation[i][j];
				endElevation = startElevation;
				currentElevation = startElevation;
				previousElevation = startElevation;
				currentPath.clear();
				currentPath.add(startElevation);
				currentLength = 1;
				currentDrop = 0;
				startX = i;
				startY = j;
				// Probiere alle m�glichen Schritte:
				explorePath(i, j, count);
			}
		}

		System.out.println("lengthOfBestPath: " + lengthOfBestPath + ", dropOfBestPath: " + dropOfBestPath);
		System.out.println("Startkoordinaten: " + bestPathStartX + "," + bestPathStartY);
		System.out.print("best path: ");
		System.out.println(bestPath.replace(", ", "-"));
	}

	// (i,j) sind die Koordinaten der aktuellen Box auf dem zu erkundenden Pfad
	// count sid die Anzahl der Iterationen
	private void explorePath(int i, int j, int count) {
		boolean performsStep = false;

		// Wenn die aktuelle Pfadl�nge gleich der Anzahl der Iterationen ist:
		if (currentPath.size() == count) {
			for (int n = -1; n <= 1; n++) {
				for (int m = -1; m <= 1; m++) {

					// Entferne den letzten Schritt aus dem Pfad (wenn es von dort nicht
					// weitergeht):
					if (currentPath.size() > count) {
						// System.out.println("count:" + count);
						currentPath.remove(currentPath.size() - 1);
					}

					performsStep = tryStep(i, j, m, n);

//					if (performsStep) {
//						System.out.println("i:" + i + " j:" + j + " m:" + m + " n:" + n);
//					}

					explorePath(i + m, j + n, count + 1);
				}
			}
		}
	}

	private boolean tryStep(int i, int j, int m, int n) {

		boolean performsStep = false;

		// Falls erlaubter Schritt (Nord, Ost, S�d oder West innerhalb der Karte):
		if ((i + m >= 0) && (i + m < X) && (j + n >= 0) && (j + n < Y) && (Math.abs(m) + Math.abs(n) == 1)) {
			currentElevation = elevation[i + m][j + n];
			if (currentPath.size() >= 1) {
				previousElevation = currentPath.get(currentPath.size() - 1);//
			}
			if (previousElevation - currentElevation > 0) {

				// Set current path:
				currentPath.add(currentElevation);
				endElevation = currentElevation;
				currentDrop = startElevation - endElevation;
				performsStep = true;
				setBestPath(currentDrop);
				
				/*
				System.out.println(currentPath.toString());
				System.out.println(m + " " + n);
				System.out.println("currentLength:" + currentPath.size() + ", currentDrop: " + currentDrop
						+ ", previousElevation:" + previousElevation + ", currentElevation:" + currentElevation);
				System.out.println("Startkoordinaten Pfad: " + startX + "," + startY);

				System.out.println("lengthOfBestPath: " + lengthOfBestPath + ", dropOfBestPath: " + dropOfBestPath
						+ ",best path: " + bestPath);
				 */
			}
		}

		return performsStep;

	}

	private void setBestPath(int currentDrop) {
		if (((currentPath.size() == lengthOfBestPath) && (currentDrop > dropOfBestPath))
				|| (currentPath.size() > lengthOfBestPath)) {
			lengthOfBestPath = currentPath.size();
			dropOfBestPath = currentDrop;
			bestPath = currentPath.toString();
			bestPathStartX = startX;
			bestPathStartY = startY;
		}
	}

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub

		SkiProblem mySkiProblem = new SkiProblem();

		mySkiProblem.parseFile();
		// mySkiProblem.showGrid();
		// mySkiProblem.printGridToFile(); //formatierte Version
		mySkiProblem.findBestPath();
	}

}
